#it is a blueprint or a template
#which describes the state/ behavior of its object
#data is put in variables
#behavior is put in functions


class Student:

    #data or the properties

    studentname="Ravi"
    studentId=677887

#self is used to access the attributes of the class we have defined
#create a function to access the data
#self represents instance of the class


    def displaystudentdetails(self):
        print(self.studentname)
        print(self.studentId)

#create the object of class
a=Student()
a.displaystudentdetails()

