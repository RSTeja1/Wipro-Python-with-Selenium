# Simple Constructor
class Student1:
    def __init__(self):
        print("This is the constructor call.....")

a = Student1()


# Parametrized Constructor
class Student2:
    def __init__(self, name, roll, course):
        self.name = name
        self.roll = roll
        self.course = course

    def display(self):
        print(self.name)
        print(self.roll)
        print(self.course)
        print("--------------------")

d = Student2("Satheesh", 1234, "Python")
d.display()

e = Student2("Vijay", 5678, "Python DSA")
e.display()


# Constructor Overloading using *args
class Numbers:
    def __init__(self, *args):
        self.values = args

n = Numbers(10, 20, 30, 40, 50)
print(n.values)

m = Numbers(2, 3, 4)
print(m.values)

p = Numbers(2)
print(p.values)
