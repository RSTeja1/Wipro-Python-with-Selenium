# default methods - built in methods , user define methods - method name, method body
#parametrized methods-
# it allows

class Calculator:
    def add(self ,a,b):
        print(a+b)

c = Calculator()
c.add(10,20)
c.add(5,7)


#default parameters
class Test:
    def run(self,browser = "chrome"):
        print("Running on", browser)

t = Test()
t.run()
t.run("Firefox")

#arguments parametrized
class Numbers:
    def total(self,*args):
        print(sum(args))

n = Numbers()
n.total(10,20,30)
n.total(10)
n.total(10,60)







