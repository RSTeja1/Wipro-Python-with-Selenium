class A:
    def show(self):
        print("Class A")

class B(A):
    pass
    #def show(self):
        #print("Class B")

class C(A):
    pass
    #def show(self):
        #print("Class C")

class D(B,C):
    pass
    #print("Class D")

d = D()
d.show()
print(D.mro())

#method from right to left
#D,B,C,A

