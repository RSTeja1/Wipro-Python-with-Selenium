



import re

#o/p match object - matched sequence and span ()-start  and end index

text ="hello world"
result = re.match("hello",text)
print(result)

#using pattern
test_str= "12345680kjdsfjh"
pattern = re.compile("123")


matches = pattern.finditer(test_str)

for match in matches:
    print(match)


#search operation searches the entire string
#returns the first occurance

text = "python of powerfull"
result = re.search("powerfull",text)
print(result)



#raw string
a = r"\thello"
print(a)

#match ()- determine if the RE matches at the beginning of the string
#search()- scan through a string , looking for any location where this RE matches
#finditer()- find all substrings where the RE matches, and returns them as an iterator
#findall()-find all ststrings where the re matches and returns a list

#findall()
my_string = 'abc123ABC123abc'
pattern = re.compile(r'123')
matches = pattern.findall(my_string)

for match in matches:
    print(match)

#methods on match

#group()- Return the string matched by the RE
#start()- Return the starting position of the match
#end()- Return the ending position of the match
#span()- Return a tuple containing the (start,end)

test_string = '123abc456789abc123ABC'
pattern = re.compile(r'abc')
matches = pattern.finditer(test_string)

for match in matches:
    print(match)
    print(match.span(),match.start(),match.end())
    print(match.group())

#special characters
#meta characters
#regular expressions

#pattern meaning

#abc matches exact text
#[abc] a or b or c
#[a-z] lowercase letters
#[0-9] digits
#'a b'
#any single character

text="i like abc and ABCDEFGHIJ"
result = re.findall("[a-z]",text)
print(result)

#[0-9]
text = "i like abc and 123456ABCDEFGHIJ"
result = re.findall("[0-9]",text)
print(result)

text = "cat bat rat"
result = re.findall("cat",text)
print(result)


#Special sequences begin with a backslash \.
#Sequence    Meaning    Example
#\d  Digit (0–9)    \d\d
#\D  Non-digit  \D
#\w  Word char (a-z, A-Z, 0-9, _)   \w+
#\W  Non-word char  \W
#\s  Whitespace \s
#\S  Non-whitespace \S
#\b  Word boundary  \bcat\b
#\B  Not a word boundary    \Bcat

#\d Digit (0-9) /d/d

print(re.findall(r"\d", "Order 123 costs450"))

#/D non-digit

print(re.findall(r"\D", "Order 123 costs450"))

#\w word char(a-z,A-Z, 0-9 _)

text = "Python_3 version!"
result = re.findall(r"\w",text)
print(result)

#\w Non-word char \w
#matches anything that is not a word character.

text= "Hello@123"
result = re.findall(r"\W", text)
print(result)

#\s whitespace spaces, tabs and newline

text = "Hello World\nPython"
result = re.findall(r"\s",text)
print(result)

#\S  Non-whitespace \S

text = "Hi There"
result = re.findall(r"/S", text)
print(result)


#\b  Word boundary  \bcat\b- Matches the position at start or end of the word

text ="cat scatter catalog"
result = re.findall(r"\bcat\b", text)
print(result)

# matches only full word "cat"

#\B  Not a word boundary    \Bcat - Matches when pattern is NOT at word boundary.

text ="cat scatter catalog"
result = re.findall(r"cat\B", text)
print(result)

#Meta - characters have special meaning in regex.
#Meta - character Meaning .Any character
#^ Start of string
#$   End of string
#*0 or more
# +   1 or more
#?   0 or 1
#{n} Exactly n times
#{n, } n or more
#{n, m} Between n and m
#[] Character set
#() Grouping


#^ start of string
text = "Python is easy"
print(re.findall(r"^Python", text))

#$ End of string
text = "Python is easy"
print(re.findall(r"easy$", text))

#* 0 or more
text = "ab abb abbb a n"
print(re.findall(r"ab*", text))

#* 1 or more
text = "ab abb abbb a"
print(re.findall(r"ab+", text))

# ? 0 or 1
text = "color colour colr"
print(re.findall(r"colou?r", text))

#{n} Exactly n times
text = "111 222 3333"
print(re.findall(r"\d{3}", text))

#{n, } n or more
text = "1 22 333 4444"
print(re.findall(r"\d{3,}", text))

#{n,m} Between n and m
text = "1 22 333 4444"
print(re.findall(r"\d{2,3}", text))

# [] Character set
text = "apple banana cat"
print(re.findall(r"[abc]", text))

# () Grouping
text = "999 777 66 88"
print(re.findall(r"\d{3}", text))

text = "apple banana cat"
print(re.findall(r"[abc]",text))

#()grouping
text = "999 777 66 88"
print(re.findall(r"\d{3}", text))

'''
Modifier    Short  Purpose
re.IGNORECASE   re.I   Case-insensitive matching
re.MULTILINE    re.M   ^ and $ match each line
re.DOTALL   re.S   . matches newline
re.VERBOSE  re.X   Write readable regex with comments
re.ASCII    re.A   ASCII-only matching
re.DEBUG    —  Debug pattern
'''

text = "Python"
print(re.search("python",text, re.I ))

#re. multi line
text = "Hello\nPython"
print(re.findall("Python",text, re.M))

#re. dotall
text = "Hello\nPython"
print(re.search("Hello.*python",text, re.S))

#re.verbose - makes it more readable
import re

pattern = re.compile(r"6w48437jhsdh..%^^&*&89")
print(pattern)

#Asci value
print(re.findall(r"\w+",text,re.A))

#re.debug
pattern = re.compile(r"6w48437jhsdh..%^^&*&89",re.DEBUG)
print(pattern)

#assertions - validating the output or checking certain condition

"""
^ → Start of string
$ → End of string
\b → Word boundary
\B → Not word boundary
(?=...) → Positive Lookahead
(?!...) → Negative Lookahead
(?<=...) → Positive Lookbehind
(?<!...) → Negative Lookbehind
"""

import re

text = "Python is easy"
print(re.findall(  r"^Python", text))


text = "Python is easy"
print(re.findall(  r"easy$", text))


text = "cat scatter catalog"
print(re.findall( r"\bcat\b", text))

text = "cat scatter catalog"
print(re.findall(  r"cat\B", text))

#(?=...)→ Positive Lookahead = match only if followed by something

text = "user1 admin2 test"
print(re.findall(  r"\w+(?=\d)", text))

#(?!...) Negative Lookahead

text = "user1 admin test2"
print(re.findall(  r"\w+(?!\d)", text))

#(?<=...) Positive Lookbehind match pnly if preceeeded by something

text = "Price 500"
print(re.findall(  r"(?<==)\d+", text))


#(?<!,..)→ Negative Lookbehind

text = "500 300"
print(re.findall( r"(?<!)\d+", text))














































