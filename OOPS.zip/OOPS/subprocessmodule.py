#subprocess module
#execute external system commands
#interact with os commands
#capture output,error and return codes
# control the process execution

#run the os level commands - linux , macos , windows



import subprocess
#subprocess.run()- run command and wait
#subprocess.Popen()- run process aynchronoulsy
#subprocess.PIPE - capture the output
#subprocess.CompleteProcess - result
#subprocess.TimeoutExpired - time outexepction
#subprocess.CalledProcessError- command failure

result = subprocess.run("dir", shell= True, capture_output=True, text= True)
print(result)

result = subprocess.run("ipconfig", shell= True, capture_output=True, text= True)
print(result)

result = subprocess.run("python --version", shell= True, capture_output=True, text= True)
print(result)
print(result.stdout)
print(result.stderr)






