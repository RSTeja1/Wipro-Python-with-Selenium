#taking many forms

#same method/ function name will behave differently depending on the
##object type
##input argmunts
#class implimentation


print(len("python"))
print(len([1,2,3]))
print(len({1,2,3}))


class calculator:
    def add(self, a,b=0,c=0):
        return a+b+c

c = calculator()
print(c.add(5))
print(c.add(5,10))
print(c.add(5,10,15))



class Animal:
    def sound(self):
        print("Animal makes a sound")

class Dog(Animal):
    def sound(self):
        print("Dog barks")

a= Dog()
a.sound()




