#skip - it defects are there
#skip - if the testcases are absolute
#windows, mobile - OS dependency
#browers - FF, IE, chrome

import pytest

# testcases1
def testcase1():
    print("Testcase1 is executed")

#testcases2
@pytest.mark.skip
def testcase2():
    print("Testcase2 is executed")

#testcase3
def testcase3():
    print("Testcase3 is executed")

#testcases4
@pytest.mark.skip
def testcase4():
    print("Opening the browser")






