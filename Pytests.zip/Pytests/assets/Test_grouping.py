#grouping - set of testcases rum together - issue fix in that module


import pytest

# testcases1
def testcase1():
    print("Testcase1 is executed")

#testcases2
@pytest.mark.sanity
def testcase2():
    print("Testcase2 is executed")

#testcase3
@pytest.mark.regression
def testcase3():
    print("Testcase3 is executed")

