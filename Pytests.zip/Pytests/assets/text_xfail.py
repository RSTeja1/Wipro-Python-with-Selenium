#xfail is a marker used to indicate that a test is expected to fail due to a known issue (e.g., a bug or an unimplemented feature)
import pytest
import sys
@pytest.mark.xfail(reason="Known bug in the third-party library")
def test_function_with_bug():
    assert (1+1)==3
@pytest.mark.sanity
def test_case1():
    print("Testcase1 is execetes")
@pytest.mark.regression
def test_case2():
    print("Testcase2 is execetes")
@pytest.mark.db
def test_case3():
    print("Testcase3 is execetes")

#xfail with a condition
@pytest.mark.xfail(sys.platform=="win32", reason="Bug on windows")
def test():
    print("test on windows")

    #this x fail  only on windows

@pytest.mark.xfail(strict=True, reason="Bug #1234 is not fixed yet")
def test_function():
    assert True