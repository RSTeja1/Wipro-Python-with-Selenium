#function level setup and teardown
#these run before and after each test function
#setup at function level
import pytest


def setup_function(function):
    print("opening the browser")
    print("navigating the home page")

#teardown up at the function
def teardown_function(function):
    print("closing the browser")
#testcae 2
@pytest.mark.sanity
def testcase1():
    print("Testcase1 is executed")
#testcase2
@pytest.mark.sanity
def testcase2():
    print("Testcase2 is executed")
#testcase3
def testcase3():
    print("Testcase3 is executed")
#testcase4
def openbrowser():
    print("Opening the browser")