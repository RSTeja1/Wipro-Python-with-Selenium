import pytest

def div(a , b):
    return a/b


def test_div_zero():
    with pytest.raises(ValueError) as exec_info:
        print(exec_info)
        div(5,0)
        assert str(exec_info.value) == "ZeroDivisionError: division by zero"