import pytest

@pytest.mark.usefixtures("dbconnection")
class TestLogin:

    def test_login(self):
        print("enter the name")
        print("enter the password")
        print("click the login button")

    def test_logout(self):
        print("user logged out")