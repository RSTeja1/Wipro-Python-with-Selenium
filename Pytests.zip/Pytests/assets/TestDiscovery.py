#unit testing is type of testing done by the developers
#what component they have developed they do the testing for it before integrating it to the other modules
#get defects earlier
#Pytest in python, junit and nunit -java
#pytest is used by developers and testers
#test_discovery - rules used to create the pytest tests

#files should start with test_
#function should start with test_

import pytest
#testcase1
def testcase1():
    print("Testcase1 is executed")
#testcase2
def testcase2():
    print("Testcase2 is executed")
#testcase3
def testcase3():
    print("Testcase3 is executed")
#testcase4
def openbrowser():
    print("Testcase1 is executed")