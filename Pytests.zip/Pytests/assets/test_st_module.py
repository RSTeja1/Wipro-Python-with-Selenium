# module level - runs once per module (file)
# use module level set up and tear down when you want to execute the set up and tear down once in the current file
# eg open the db connection execute all the testcases and at alst close the db connection

import pytest
def setup_module(module):
    print("opening the browser")

def setup_module(module):
    print("opening the schema")

def teardown_module(module):
    print("closing the schema")

#teardown up at the function
def teardown_function(function):
    print("closing the browser")
#testcae 2
def test_read():
    print("Reading the db")
#testcase2
def test_write():
    print("writing the data to be db")
#testcase3
def test_update():
    print("Updating db")
