class Car:
    def __init__(self, brand, model, price):
        self.brand = brand
        self.model = model
        self.price = price

car1 = Car("Toyota", "Camry", 30000)
print(car1.brand, car1.model, car1.price)


#2
class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

    def get_grade(self):
        if self.marks >= 90:
            return "A"
        elif self.marks >= 75:
            return "B"
        elif self.marks >= 50:
            return "C"
        else:
            return "Fail"

s1 = Student("Vijay", 82)
print(s1.get_grade())

#3
class BankAccount:
    def __init__(self, balance=0):
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount

    def withdraw(self, amount):
        if amount <= self.balance:
            self.balance -= amount
        else:
            print("Insufficient balance")

acc = BankAccount(1000)
acc.deposit(500)
acc.withdraw(300)
print(acc.balance)

#4
class Employee:
    def __init__(self, name, emp_id, salary):
        self.name = name
        self.emp_id = emp_id
        self.salary = salary

#5
class Counter:
    count = 0

    def __init__(self):
        Counter.count += 1

obj1 = Counter()
obj2 = Counter()
print("Objects created:", Counter.count)

#6
class Company:
    company_name = "TechCorp"

    def __init__(self, employee):
        self.employee = employee

print(Company.company_name)

#7
class Validator:
    @staticmethod
    def validate_email(email):
        return "@" in email and "." in email

print(Validator.validate_email("test@gmail.com"))

#8
class Vehicle:
    def start(self):
        print("Vehicle starts")

class Bike(Vehicle):
    def ride(self):
        print("Bike is riding")

b = Bike()
b.start()
b.ride()

#9
class Person:
    def show_person(self):
        print("I am a person")

class Employee(Person):
    def show_employee(self):
        print("I am an employee")

class Manager(Employee):
    def show_manager(self):
        print("I am a manager")

m = Manager()
m.show_person()
m.show_employee()
m.show_manager()

#10
class Parent:
    def show(self):
        print("Parent method")

class Child(Parent):
    def show(self):
        super().show()
        print("Child method")

c = Child()
c.show()

#11
class BankAccount:
    def __init__(self):
        self.__balance = 0

    def deposit(self, amount):
        self.__balance += amount

    def get_balance(self):
        return self.__balance

acc = BankAccount()
acc.deposit(500)
print(acc.get_balance())

#12
class Account:
    def __init__(self):
        self.__balance = 0

    def set_balance(self, amount):
        if amount >= 0:
            self.__balance = amount

    def get_balance(self):
        return self.__balance

#13
class Employee:
    def __init__(self, salary):
        self._salary = salary

    @property
    def salary(self):
        return self._salary

    @salary.setter
    def salary(self, value):
        if value < 0:
            print("Salary cannot be negative")
        else:
            self._salary = value

e = Employee(5000)
e.salary = -1000
print(e.salary)

#14
import math

class Shape:
    def area(self):
        pass

class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius * self.radius

class Rectangle(Shape):
    def __init__(self, l, b):
        self.l = l
        self.b = b

    def area(self):
        return self.l * self.b

#15
class Calculator:
    def add(self, a, b=0, c=0):
        return a + b + c

cal = Calculator()
print(cal.add(5))
print(cal.add(5, 3))
print(cal.add(5, 3, 2))

#16
class Number:
    def __init__(self, value):
        self.value = value

    def __add__(self, other):
        return Number(self.value + other.value)

n1 = Number(10)
n2 = Number(20)
n3 = n1 + n2
print(n3.value)

#17
class Engine:
    def start(self):
        print("Engine started")

class Car:
    def __init__(self):
        self.engine = Engine()

    def start_car(self):
        self.engine.start()

c = Car()
c.start_car()

#18
class Player:
    def __init__(self, name):
        self.name = name

class Team:
    def __init__(self, name):
        self.name = name
        self.players = []

    def add_player(self, player):
        self.players.append(player)

team = Team("Warriors")
team.add_player(Player("Rahul"))
team.add_player(Player("Arjun"))

for p in team.players:
    print(p.name)




