
def print_even_number():
    for num in range(1,51):
        if num %2 ==0:
            print(num)
            print_even_number()

#scenraio fall numbers
def check_range(number, lower, upper):
    if lower<=number<=upper:
        print(f"{number}is within the range {lower} to {upper}")
    else:
        print(f"{number}is within the range {lower} to {upper}")

# add numbers from 1 to 100
def sum_1_to_100():
    total = 0
    for num in range(1, 101):
        total += num
    return total

print(sum_1_to_100())


#divisible by 5
for num in range(1, 101):
    if num % 5 == 0:
        print(num)

#list of numbers
numbers = list(range(50, 101, 5))
print(numbers)

#square of each number
for num in range(1, 11):
    print(num * num)

#range from -10 to 10
for num in range(-10, 11):
    print(num)

