#1
def sum_list(numbers):
    total = 0
    for num in numbers:
        total += num
    return total

# Example
nums = [10, 20, 30, 40]
print(sum_list(nums))

#2
def max_of_three(a, b, c):
    if a >= b and a >= c:
        return a
    elif b >= a and b >= c:
        return b
    else:
        return c

# Example
print(max_of_three(10, 25, 15))







