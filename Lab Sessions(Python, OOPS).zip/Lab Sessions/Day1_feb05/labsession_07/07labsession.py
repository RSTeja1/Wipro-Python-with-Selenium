#2
while True:
    try:
        num = int(input("Enter a number: "))
        print("Valid input:", num)
        break
    except ValueError:
        print("Invalid input! Try again.")

#3
import random
import string

# Random single alphabetical character
random_char = random.choice(string.ascii_letters)
print("Random Character:", random_char)

# Random alphabetical string (random length)
length = random.randint(5, 10)
random_string = ''.join(random.choice(string.ascii_letters) for _ in range(length))
print("Random String:", random_string)

# Random alphabetical string of fixed length
fixed_length = 8
fixed_string = ''.join(random.choice(string.ascii_letters) for _ in range(fixed_length))
print("Fixed Length String:", fixed_string)





