import pytest
import requests


# Base URL fixture
@pytest.fixture(scope="session")
def base_url():
    return "https://jsonplaceholder.typicode.com"


# Auth token fixture (runs once per session)
@pytest.fixture(scope="session")
def auth_token():
    token = "dummy_token_12345"
    return token


# User fixture using yield (setup + teardown)
@pytest.fixture
def user(base_url):
    payload = {
        "name": "pytest_user",
        "email": "pytest@test.com"
    }

    response = requests.post(f"{base_url}/users", json=payload)
    created_user = response.json()

    # provide to test
    yield created_user

    # cleanup after test
    print("User deleted")