import pytest
import requests


# Q1. Write a pytest fixture that generates an authentication token once per session and use it in multiple API test cases.
@pytest.fixture(scope="session")
def auth_token():
    token = "dummy_token_12345"
    return token


# Q5. Create a fixture chain: base_url -> auth_token -> user -> test case.
@pytest.fixture(scope="session")
def base_url():
    return "https://jsonplaceholder.typicode.com"


# Q2. Create a fixture that creates a test user via API before a test and deletes the user after test execution using yield.
@pytest.fixture
def user(base_url):
    payload = {
        "name": "pytest_user",
        "email": "pytest@test.com"
    }

    response = requests.post(f"{base_url}/users", json=payload)
    created_user = response.json()

    yield created_user

    # Cleanup (simulation)
    print("User deleted")


# Q3. Write a test that validates JSON response schema from an API endpoint.
def test_json_schema_validation(base_url):
    response = requests.get(f"{base_url}/users/1")

    assert response.status_code == 200

    data = response.json()

    assert isinstance(data["id"], int)
    assert isinstance(data["name"], str)
    assert isinstance(data["email"], str)

    expected_keys = {"id", "name", "email"}
    assert expected_keys.issubset(data.keys())


# Q4. Implement a parametrized test that validates multiple HTTP status codes (200, 400, 401, 500).
@pytest.mark.parametrize("status_code", [200, 400, 401, 500])
def test_status_codes(status_code):
    response = requests.get(f"https://httpbin.org/status/{status_code}")
    assert response.status_code == status_code


# Q5. Create a fixture chain: base_url -> auth_token -> user -> test case. Explain execution order.
def test_fixture_chain(base_url, auth_token, user):
    assert user is not None