#1
class MyIterator:
    def __init__(self):
        self.num = 1

    def __iter__(self):
        return self

    def __next__(self):
        if self.num <= 5:
            value = self.num
            self.num += 1
            return value
        else:
            raise StopIteration

# Using the custom iterator
for i in MyIterator():
    print(i)

#2
def even_numbers(start, end):
    for i in range(start, end + 1):
        if i % 2 == 0:
            yield i

for n in even_numbers(1, 10):
    print(n)

#3
class EvenIterator:
    def __init__(self, limit):
        self.num = 0
        self.limit = limit

    def __iter__(self):
        return self

    def __next__(self):
        if self.num <= self.limit:
            even = self.num
            self.num += 2
            return even
        else:
            raise StopIteration

for x in EvenIterator(10):
    print(x)

#1 generators
def generate_numbers(n):
    for i in range(1, n + 1):
        yield i

# Using the generator
N = int(input("Enter N: "))

for num in generate_numbers(N):
    print(num)

#2

def infinite_even():
    num = 0
    while True:
        yield num
        num += 2

# Example (print first 5 even numbers)
gen = infinite_even()
for _ in range(5):
    print(next(gen))

#3
def read_file(filename):
    with open(filename, "r") as file:
        for line in file:
            yield line.strip()

for line in read_file("C://Users//ansur//PycharmProjects//PythonProject//Dataformats//data.csv"):
        print(line)


#4
def fibonacci(n):
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b

# Example
for num in fibonacci(10):
    print(num)

#5
def retry_generator(max_retries=3):
    for attempt in range(1, max_retries + 1):
        yield f"Retry attempt {attempt}"

# Using the generator
for retry in retry_generator():
    print(retry)











