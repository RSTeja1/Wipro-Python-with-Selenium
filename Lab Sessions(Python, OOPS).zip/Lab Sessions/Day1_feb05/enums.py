# enumerate the starting value
#returns index and value together

fruits = ["orange","cherry","kiwi"]
for index,fruit in enumerate(fruits):
    print(index,fruit)

#enumerate with strings
word = "python"
for i, ch in enumerate(word, start = 2):
    print(i,ch)

#real tym scenarios
test_cases = ["Login","Signup","Checkout"]
for case_no, test in enumerate (test_cases, start =1):
    print(f"Executing Testcase {case_no}:{test}")

#accesing the enumerate values
a=['God', 'is', 'great']
b= enumerate(a)
nxt_val = next(b)
print(nxt_val)

#duplicate detection usif enumeration
characters=["surya","teja","teja","samyu","reshma",
             "surya","teja","ram","samyu","reshma",
            "samyu","reshma", "surya","teja","ram"]

character_map = {character: []for character in set (characters)}

for index, character in enumerate(characters):
    character_map[character].append(index)
print(character_map)