#1st ques
# Class definition
class Book:
    def __init__(self, title, author):
        self.title = title
        self.author = author

    def display(self):
        print("Title:", self.title)
        print("Author:", self.author)
        print("-------------------")


# Creating 3 book objects
b1 = Book("Python Basics", "John Smith")
b2 = Book("Data Science Guide", "Alice Brown")
b3 = Book("Machine Learning", "David Lee")

# Printing book details
b1.display()
b2.display()
b3.display()

#2nd question
class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width

        # Store area and perimeter as attributes
        self.area = length * width
        self.perimeter = 2 * (length + width)

    def display(self):
        print("Length:", self.length)
        print("Width:", self.width)
        print("Area:", self.area)
        print("Perimeter:", self.perimeter)


# Creating objects
r1 = Rectangle(5, 3)
r2 = Rectangle(10, 4)

# Display details
r1.display()
print("------")
r2.display()


# Inheritance programs (single)
# Parent Class
class SavingsAccount:
    def __init__(self, balance=0):
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount
        print("Deposited Amount:", amount)
        print("Current Balance:", self.balance)


# Child Class
class InterestAccount(SavingsAccount):
    def addInterest(self, rate):
        interest = (self.balance * rate) / 100
        self.balance += interest
        print("Interest Added:", interest)
        print("Total Balance after Interest:", self.balance)


# Creating Object of Child Class
acc = InterestAccount()

acc.deposit(1000)     # Parent class function
acc.addInterest(5)    # Child class function


# Multiple

# Parent Class 1
class SavingsAccount:
    def __init__(self, balance=0):
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount
        print("Deposited:", amount)
        print("Current Balance:", self.balance)


# Parent Class 2
class InterestAccount:
    def addinterest(self, rate):
        interest = self.balance * rate / 100
        self.balance += interest
        print("Interest Added:", interest)
        print("Balance After Interest:", self.balance)


# Child Class (Multiple Inheritance)
class BankAccount(SavingsAccount, InterestAccount):
    pass


# Creating object
acc = BankAccount(1000)   # initial balance

acc.deposit(500)          # deposit money
acc.addinterest(10)       # add 10% interest

#1 Evening

import math

class Circle:
    def __init__(self, radius):
        self.radius = radius

    # Method to calculate area
    def area(self):
        return math.pi * self.radius ** 2

    # Method to calculate perimeter (circumference)
    def perimeter(self):
        return 2 * math.pi * self.radius


# Create object
c = Circle(5)

print("Radius:", c.radius)
print("Area:", c.area())
print("Perimeter:", c.perimeter())

#2
from datetime import date

class Person:
    def __init__(self, name, country, dob):   # dob in YYYY-MM-DD format
        self.name = name
        self.country = country
        self.dob = dob

    # Method to calculate age
    def age(self):
        birth_year, birth_month, birth_day = map(int, self.dob.split("-"))
        today = date.today()

        age = today.year - birth_year
        if (today.month, today.day) < (birth_month, birth_day):
            age -= 1
        return age


# Create object
p = Person("Satheesh", "India", "2000-05-10")

print("Name:", p.name)
print("Country:", p.country)
print("Date of Birth:", p.dob)
print("Age:", p.age())

#3
import math

# Parent Class
class Shape:
    def area(self):
        pass

    def perimeter(self):
        pass


# Child Class: Circle
class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2

    def perimeter(self):
        return 2 * math.pi * self.radius


# Child Class: Square
class Square(Shape):
    def __init__(self, side):
        self.side = side

    def area(self):
        return self.side * self.side

    def perimeter(self):
        return 4 * self.side


# Child Class: Triangle
class Triangle(Shape):
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

    def area(self):
        # Heron's formula
        s = (self.a + self.b + self.c) / 2
        return math.sqrt(s * (s - self.a) * (s - self.b) * (s - self.c))

    def perimeter(self):
        return self.a + self.b + self.c


# Create objects
c = Circle(5)
s = Square(4)
t = Triangle(3, 4, 5)

print("Circle Area:", c.area())
print("Circle Perimeter:", c.perimeter())

print("Square Area:", s.area())
print("Square Perimeter:", s.perimeter())

print("Triangle Area:", t.area())
print("Triangle Perimeter:", t.perimeter())

#4
# Parent Class
class Vehicle:
    def __init__(self, name, max_speed, mileage):
        self.name = name
        self.max_speed = max_speed
        self.mileage = mileage

    def display(self):
        print("Vehicle Name:", self.name)
        print("Max Speed:", self.max_speed)
        print("Mileage:", self.mileage)


# Child Class
class Bus(Vehicle):
    pass   # inherits everything from Vehicle


# Create object of Bus
b = Bus("School Bus", 80, 12)

b.display()

#5
class Vehicle:
    pass   # Empty class with no variables and no methods

# Create an object
v = Vehicle()
print("Vehicle object created:", v)









