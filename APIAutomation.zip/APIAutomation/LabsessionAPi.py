import requests
import json

#1
print("\n1 Name and Email")
response = requests.get("https://jsonplaceholder.typicode.com/users")
users = response.json()

for user in users:
    print(user["name"], "-", user["email"])


#2
print("\n2️ Posts count for userId=2")
params = {"userId": 2}

response = requests.get(
    "https://jsonplaceholder.typicode.com/posts",
    params=params
)

posts = response.json()
print("Number of posts:", len(posts))


#3
print("\n3️ POST request")
data = {
    "title": "New Post",
    "body": "This is a test post",
    "userId": 1
}

response = requests.post(
    "https://jsonplaceholder.typicode.com/posts",
    json=data
)

if response.status_code == 201:
    print("Resource created successfully")
else:
    print("Failed:", response.status_code)


#4
print("\n4 data= vs json=")
print("data= → sends form data")
print("json= → sends JSON + sets content-type automatically")


#5
print("\n5️ Status check")
response = requests.get("https://jsonplaceholder.typicode.com/users")

if response.status_code != 200:
    raise Exception(f"Request failed: {response.status_code}")

print("Status code is 200")


#6
print("\n6️ Usernames in UPPERCASE")
for user in users:
    print(user["username"].upper())


#7
print("\n7️ Timeout handling")
try:
    response = requests.get(
        "https://jsonplaceholder.typicode.com/users",
        timeout=2
    )
    print("Request successful")

except requests.exceptions.Timeout:
    print("Request timed out")


#8
print("\n8️ Session example")

session = requests.Session()

session.get("https://httpbin.org/cookies/set?name=vijay")
r2 = session.get("https://httpbin.org/cookies")

print("Cookies:", r2.json())


#9
print("\n9️ File upload")

# Make sure sample.txt exists in same folder
files = {"file": open("sample.txt", "rb")}

response = requests.post(
    "https://httpbin.org/post",
    files=files
)

print("Upload Response:", response.status_code)


#10
print("\n10 Save posts to file")

response = requests.get("https://jsonplaceholder.typicode.com/posts")
posts = response.json()

with open("posts.json", "w") as file:
    json.dump(posts, file, indent=4)

print("posts.json created successfully")