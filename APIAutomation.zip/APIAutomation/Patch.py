import requests
try:
    data = {
        "name": "Apple MacBook Pro 16 (Updated Name)"
    }
    # Fix: Changed 'url:' to 'url='
    # Note: This uses a different base URL (restful-api.dev)
    response = requests.patch("https://api.restful-api.dev/objects/ff8081819c5368bb019c55a3762204", json=data)
    print(response)

    if response.status_code == 200:
        print("Status code is 200 OK")
        data = response.json()
        print(data)
    else:
        print(f"Error: Received status code {response.status_code}")
except requests.exceptions.RequestException as e:
    print(f"An error occurred: {e}")