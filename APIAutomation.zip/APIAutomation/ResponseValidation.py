import requests
from requests.auth import HTTPBasicAuth

try:
    data = {
        "category": "Platform",
        "name": "Mario",
        "rating": "Mature",
        "releaseDate": "2012-05-04",
        "reviewScore": 85
    }

    response = requests.post(
        "https://videogamedb.uk/api/v2/videogame",
        json=data
    )
    if response.status_code == 200:
        print("Status code is 200 OK")

        # parse the json file
        data = response.json()

        # text of the response file
        print(response.text)

        # content of the response
        print(response.content)

        # status code of the response
        print(response.status_code)

        # headers
        print(response.headers)

        # history
        print(response.history)

        # url
        print(response.url)

        # fetch the single header
        content_type = response.headers.get('Content-Type')
        print(content_type)

    else:
        print(f"Error: Received status code {response.status_code}")

except requests.exceptions.RequestException as e:
    print("Error:", e)