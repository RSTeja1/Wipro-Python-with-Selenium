*** Settings ***
Library    SeleniumLibrary

*** Variables ***
${URL}    https://www.tutorialspoint.com/selenium/practice/frames.php

*** Test Cases ***
Verify Frames
    Open Browser    ${URL}    chrome
    Maximize Browser Window
    Set Selenium Implicit Wait    5s

    # Switch to First Frame (index 0)
    Select Frame    xpath=(//iframe)[1]
    Element Should Be Visible    xpath=//h1
    Unselect Frame

    # Switch to Second Frame (index 1)
    Select Frame    xpath=(//iframe)[2]
    Element Should Be Visible    xpath=//h1
    Unselect Frame

    Close Browser