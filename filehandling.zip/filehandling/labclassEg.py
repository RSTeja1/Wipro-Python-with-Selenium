# Create Employee class
class Employee:

    # Constructor to initialize data
    def __init__(self, emp_id, emp_name, emp_dept):
        self.emp_id = emp_id
        self.emp_name = emp_name
        self.emp_dept = emp_dept

    # Function to display employee details
    def display(self):
        print("Employee ID:", self.emp_id)
        print("Employee Name:", self.emp_name)
        print("Department:", self.emp_dept)
        print("------------------------")


# Create 2 objects
e1 = Employee(101, "Teja", "IT")
e2 = Employee(102, "Rahul", "HR")

# Display data
e1.display()
e2.display()
