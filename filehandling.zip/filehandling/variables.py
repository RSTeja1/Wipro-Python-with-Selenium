#used to store the data
#instance variable -