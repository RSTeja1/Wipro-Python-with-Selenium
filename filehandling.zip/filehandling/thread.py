#it is execution of task
#multithreading is execution of many tasks - concurrent execution
#multiprocessing -
#threading imported

#Process - execution unit
#threads - light weight unite inside  the process

import threading
import time


def task():
    print("Thread started")
    time.sleep(2)
    print("Thread finished")

t = threading.Thread(target=task)
t.start()
t.join()

print("Thread terminated")

#multi threading
import threading






