#destructors - when we want to destroy the object
#for proper memory usage destructors should be used
#when db connection has to be closed



class Desct:
    def __init__(self):
        print("Object created")

    def __del__(self):
        print("Closing the db connection")

a= Desct()
print("End Of the program")
del a

class Filehandler:
    def __init__(self,filename):
        self.file = open(filename, 'w')
        print("File is opened")

    def readfile(self, filename):
        print("Reading the file")

    def __del__(self):
        self.file.close()
        print("File closed")

f = Filehandler("test.txt")
f.readfile("test.txt")
del f