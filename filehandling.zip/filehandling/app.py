#flask - python web fw- web apps, rest apis and microservices

from flask import Flask, jsonify, request

#creates flask object
app = Flask(__name__)

@app.route("/")
def home():
    return "welcome to Flask web server!"

#get method end point
@app.route('/users',methods = ['GET'])
def get_user():
    return jsonify({"user":["Alice","Bob","Charlie"]})

#post method and point
@app.route('/users',methods = ['POST'])
def add_users():
    data = request.get_json()
    return jsonify(data),201

#put
@app.route('/users/<int:id>',methods = ['PUT'])
def update_users(id):
    return jsonify({"Message":f"user{id}is update"})

#delete
@app.route('/users/<int:id>',methods = ['DELETE'])
def delete_users(id):
    return jsonify({"Message":f"user{id}is deleted"})


#patch
@app.route('/users/<int:id>', methods=['PATCH'])
def patch_user(id):
    data = request.get_json()
    return jsonify({
        "message": "User updated partially",
        "user_id": id,
        "updated_fields": data
    })



#run the below code when this file is executed directly and not when imported
if __name__ == "__main__":
    app.run(debug = True)

#run the local server - on http local host : 5000
#enable the debugging mode












